
  # Create Hellenic Berserk Background

  This is a code bundle for Create Hellenic Berserk Background. The original project is available at https://www.figma.com/design/YOBaSxxhbeA36dw21ZjYbi/Create-Hellenic-Berserk-Background.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  