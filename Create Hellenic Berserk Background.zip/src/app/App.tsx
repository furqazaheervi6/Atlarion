import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { useState, useEffect } from 'react';

export default function App() {
  const [currentVersion, setCurrentVersion] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVersion((prev) => (prev + 1) % 3);
    }, 12000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative size-full overflow-hidden bg-black">
      {/* Base layer - Greek temple ruins with subtle movement */}
      <motion.div
        className="absolute inset-0"
        animate={{
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1508174516034-a466529afd78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxhbmNpZW50JTIwZ3JlZWslMjB0ZW1wbGUlMjBydWlucyUyMGRhcmt8ZW58MXx8fHwxNzc5NTE4MzUwfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Ancient Greek temple ruins at night"
          className="w-full h-full object-cover opacity-30 grayscale"
          style={{ filter: 'brightness(0.3) contrast(1.4)' }}
        />
      </motion.div>

      {/* Dark gradient overlays for Berserk atmosphere with subtle animation */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80"
        animate={{
          opacity: [1, 0.85, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/40"
        animate={{
          opacity: [1, 0.9, 1],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1
        }}
      />

      {/* Central statue - changes based on version */}
      <AnimatePresence mode="wait">
        {currentVersion === 0 && (
          <motion.div
            key="statue-v1"
            className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full"
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 2, ease: "easeOut" }}
          >
            <motion.div
              className="w-full h-full"
              animate={{
                y: [-10, 10, -10],
                scale: [1, 1.02, 1],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1679432095838-4945da3b0365?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlayUyMHdhcnJpb3IlMjBzdGF0dWUlMjBzcGFydGElMjBhbmNpZW50fGVufDF8fHx8MTc3OTUxODcxOHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Greek warrior statue"
                className="w-full h-full object-cover opacity-75"
                style={{ filter: 'brightness(0.5) contrast(1.8) saturate(0.3)' }}
              />
            </motion.div>
          </motion.div>
        )}

        {currentVersion === 1 && (
          <motion.div
            key="statue-v2"
            className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full"
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 2, ease: "easeOut" }}
          >
            <motion.div
              className="w-full h-full"
              animate={{
                y: [-10, 10, -10],
                scale: [1, 1.02, 1],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1742467909368-bd6eb5a76e86?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw1fHxoZXJvaWMlMjBzdGF0dWUlMjBidXJkZW4lMjBzdHJlbmd0aCUyMGFuY2llbnR8ZW58MXx8fHwxNzc5NTE4NTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Atlas bearing the weight of the world"
                className="w-full h-full object-cover opacity-80"
                style={{ filter: 'brightness(0.5) contrast(1.8) saturate(0.3)' }}
              />
            </motion.div>
          </motion.div>
        )}

        {currentVersion === 2 && (
          <motion.div
            key="statue-v3"
            className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full"
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 2, ease: "easeOut" }}
          >
            <motion.div
              className="w-full h-full"
              animate={{
                y: [-10, 10, -10],
                scale: [1, 1.02, 1],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1571033690858-b336bfa1dd0f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmNpZW50JTIwZ3JlZWslMjBtYXJibGUlMjBzdGF0dWUlMjBtdXNjdWxhciUyMGhlcm9pY3xlbnwxfHx8fDE3Nzk1MTg1NDZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Heroic Greek titan looking upward"
                className="w-full h-full object-cover opacity-75"
                style={{ filter: 'brightness(0.45) contrast(1.9) saturate(0.25)' }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Secondary depth layer for all versions */}
      <motion.div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full pointer-events-none"
        animate={{ opacity: currentVersion === 1 ? 0.2 : 0.15 }}
        transition={{ duration: 1.5 }}
      >
        <motion.div
          className="w-full h-full"
          animate={{
            y: [-5, 5, -5],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5
          }}
        >
          <div className="w-full h-full opacity-20 blur-sm mix-blend-screen bg-gradient-to-b from-gray-600 to-gray-800" />
        </motion.div>
      </motion.div>

      {/* Medieval armor layer - right side with parallax */}
      <motion.div
        className="absolute top-0 right-0 w-2/5 h-full"
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 1.5, ease: "easeOut", delay: 0.3 }}
      >
        <motion.div
          className="w-full h-full"
          animate={{
            x: [-8, 8, -8],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1553986782-9f6de60b51b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwbWVkaWV2YWwlMjBhcm1vciUyMHdhcnJpb3J8ZW58MXx8fHwxNzc5NTE4MTI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Medieval warrior armor"
            className="w-full h-full object-cover opacity-60"
            style={{ filter: 'brightness(0.4) contrast(1.6)' }}
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-l from-transparent via-black/50 to-black" />
      </motion.div>

      {/* Noise texture overlay for gritty Berserk feel */}
      <div 
        className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none"
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 400 400\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")',
          backgroundRepeat: 'repeat'
        }}
      />

      {/* Animated mist/fog layers */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, transparent 0%, rgba(100,100,100,0.1) 50%, transparent 100%)',
          mixBlendMode: 'screen'
        }}
        animate={{
          x: ['-100%', '100%'],
          opacity: [0, 0.3, 0]
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'linear-gradient(45deg, transparent 0%, rgba(80,80,80,0.08) 50%, transparent 100%)',
          mixBlendMode: 'overlay'
        }}
        animate={{
          x: ['100%', '-100%'],
          y: ['-50%', '50%'],
          opacity: [0, 0.2, 0]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
          delay: 3
        }}
      />

      {/* Vignette effect */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 20%, rgba(0,0,0,0.4) 70%, rgba(0,0,0,0.8) 100%)'
        }}
      />

      {/* Animated light rays from above - varies by version */}
      <motion.div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1/2 pointer-events-none"
        animate={{
          opacity: currentVersion === 0 ? [0, 0.12, 0] : currentVersion === 1 ? [0, 0.15, 0] : [0, 0.18, 0]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.1) 0%, transparent 100%)',
          mixBlendMode: 'overlay'
        }}
      />

      {/* Red accent glow - Berserk's Brand of Sacrifice reference */}
      <motion.div
        className="absolute top-1/4 left-1/3 w-96 h-96 rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, #8b0000 0%, transparent 70%)' }}
        animate={{
          opacity: currentVersion === 0 ? [0.15, 0.22, 0.15] : currentVersion === 1 ? [0.1, 0.18, 0.1] : [0.18, 0.25, 0.18],
          scale: [1, 1.15, 1],
          x: [-20, 20, -20],
          y: [-10, 10, -10]
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Secondary red glow */}
      <motion.div
        className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, #660000 0%, transparent 70%)' }}
        animate={{
          opacity: currentVersion === 2 ? [0.12, 0.18, 0.12] : [0.08, 0.12, 0.08],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1.5
        }}
      />

      {/* Third red glow for version 2 */}
      <motion.div
        className="absolute top-1/2 left-1/4 w-72 h-72 rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, #8b0000 0%, transparent 70%)' }}
        animate={{
          opacity: currentVersion === 2 ? [0.08, 0.15, 0.08] : [0, 0, 0],
          scale: [1, 1.25, 1],
          x: [10, -10, 10],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2
        }}
      />

      {/* Floating particles for atmosphere */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white/20 rounded-full blur-sm"
          style={{
            left: `${15 + (i * 7)}%`,
            top: `${20 + (i * 5)}%`,
          }}
          animate={{
            y: [0, -100, 0],
            x: [0, Math.sin(i) * 30, 0],
            opacity: [0, 0.3, 0],
          }}
          transition={{
            duration: 8 + i * 0.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.4
          }}
        />
      ))}

      {/* Content overlay - cycling text versions */}
      <div className="relative z-10 flex items-center justify-center size-full">
        <AnimatePresence mode="wait">
          {currentVersion === 0 && (
            <motion.div
              key="version1"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="text-center absolute"
            >
              <motion.h1
                className="text-6xl font-bold tracking-wider mb-4"
                style={{
                  color: '#c9c9c9',
                  textShadow: '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                  fontFamily: 'serif',
                  letterSpacing: '0.15em'
                }}
                animate={{
                  textShadow: [
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                    '0 0 35px rgba(0,0,0,0.9), 0 0 15px rgba(139,0,0,0.7)',
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)'
                  ]
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                ΕΛΛΑΣ
              </motion.h1>
              <p
                className="text-xl tracking-widest opacity-80"
                style={{
                  color: '#8b8b8b',
                  textShadow: '0 0 20px rgba(0,0,0,0.9)',
                  letterSpacing: '0.3em'
                }}
              >
                IN SHADOWS WE STAND
              </p>
            </motion.div>
          )}

          {currentVersion === 1 && (
            <motion.div
              key="version2"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="text-center absolute"
            >
              <motion.h1
                className="text-5xl font-bold tracking-wide max-w-4xl px-8"
                style={{
                  color: '#c9c9c9',
                  textShadow: '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                  fontFamily: 'serif',
                  letterSpacing: '0.08em',
                  lineHeight: '1.3'
                }}
                animate={{
                  textShadow: [
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                    '0 0 35px rgba(0,0,0,0.9), 0 0 15px rgba(139,0,0,0.7)',
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)'
                  ]
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                There is no paradise for you to return to
              </motion.h1>
            </motion.div>
          )}

          {currentVersion === 2 && (
            <motion.div
              key="version3"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="text-center absolute"
            >
              <motion.h1
                className="text-6xl font-bold tracking-wider mb-4"
                style={{
                  color: '#c9c9c9',
                  textShadow: '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                  fontFamily: 'serif',
                  letterSpacing: '0.12em'
                }}
                animate={{
                  textShadow: [
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)',
                    '0 0 35px rgba(0,0,0,0.9), 0 0 15px rgba(139,0,0,0.7)',
                    '0 0 30px rgba(0,0,0,0.9), 0 0 10px rgba(139,0,0,0.5)'
                  ]
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                ATLAS
              </motion.h1>
              <p
                className="text-2xl tracking-widest opacity-80 max-w-3xl"
                style={{
                  color: '#8b8b8b',
                  textShadow: '0 0 20px rgba(0,0,0,0.9)',
                  letterSpacing: '0.25em'
                }}
              >
                ETERNAL BURDEN
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Version indicator dots with labels */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20">
        <div className="flex gap-8 items-center">
          {[
            { index: 0, label: 'HELLAS' },
            { index: 1, label: 'ATLAS' },
            { index: 2, label: 'TITAN' }
          ].map(({ index, label }) => (
            <motion.button
              key={index}
              onClick={() => setCurrentVersion(index)}
              className="flex flex-col items-center gap-2 cursor-pointer group"
              whileHover={{ scale: 1.1 }}
            >
              <motion.div
                className="w-3 h-3 rounded-full border border-white/30 relative"
                animate={{
                  backgroundColor: currentVersion === index ? 'rgba(139, 0, 0, 0.8)' : 'rgba(255, 255, 255, 0.2)',
                  scale: currentVersion === index ? 1.3 : 1,
                  boxShadow: currentVersion === index ? '0 0 15px rgba(139, 0, 0, 0.6)' : '0 0 0px rgba(0,0,0,0)'
                }}
                transition={{ duration: 0.3 }}
              >
                {currentVersion === index && (
                  <motion.div
                    className="absolute inset-0 rounded-full"
                    style={{ backgroundColor: 'rgba(139, 0, 0, 0.4)' }}
                    initial={{ scale: 1 }}
                    animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}
              </motion.div>
              <motion.span
                className="text-xs tracking-widest font-bold"
                style={{
                  color: currentVersion === index ? '#c9c9c9' : '#4a4a4a',
                  textShadow: currentVersion === index ? '0 0 10px rgba(139, 0, 0, 0.5)' : 'none',
                  letterSpacing: '0.15em'
                }}
                animate={{
                  opacity: currentVersion === index ? 1 : 0.5
                }}
              >
                {label}
              </motion.span>
            </motion.button>
          ))}
        </div>

        {/* Progress bar */}
        <motion.div
          className="mt-6 h-0.5 bg-white/10 rounded-full overflow-hidden"
          style={{ width: '240px' }}
        >
          <motion.div
            className="h-full bg-gradient-to-r from-red-900/50 to-red-600/80"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: 'linear'
            }}
            key={currentVersion}
          />
        </motion.div>
      </div>
    </div>
  );
}